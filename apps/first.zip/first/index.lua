content("text/html; charset=utf-8")
print("First self-contained Algernon application")
